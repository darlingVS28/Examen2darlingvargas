﻿namespace Examen2darlingvargassequeira.Properties
{
    public class Class
    {
    }
}
