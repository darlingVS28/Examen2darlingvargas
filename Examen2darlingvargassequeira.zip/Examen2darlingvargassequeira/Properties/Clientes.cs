﻿namespace Examen2darlingvargassequeira.Properties
{
    public class Clientes
    {
        private static string nombre { get; set; }
        private static string cedula { get; set; }

        private static string telefono { get; set; }

        private static string direccion { get; set; }

        // Constructor de la clase
        public Clientes (string nom, string contrasena, string telefono, string direccion)
        {
            nombre = nom;
            cedula = cedula;
            direccion = direccion;
            telefono = telefono;
        }


        public static string GetNombre() { return nombre; }
        public static string GetCedula() { return cedula; }

        public static string Getdireccion() { return direccion; }

        public static string Gettelefono() { return telefono; }

        public static void Setnombre(string nom)
        {
            nombre = nom;
        }
        public static void SetClave(String contrasena)
        {
            cedula = cedula;
        }

        public static void Setdireccion(string nom)
        {
            direccion = direccion;
        }

        public static void Settelefono(string nom)
        {
            telefono = telefono;
        }
    }

    public static Boolean AgregarUsuario()
    {
        Boolean existe = false;
        string s = System.Configuration.ConfigurationManager.ConnectionStrings["Examen2DBConnectionString"].ConnectionString;
        SqlConnection conexion = new SqlConnection(s);
        try
        {

            conexion.Open();
            SqlCommand comando = new SqlCommand(" Clientes (nombre,cedula,direccion,telefono) " +
                "values ('" + nombre + "','" + cedula + "')", conexion);
            comando.ExecuteNonQuery();
            existe = true;

        }
        catch (Exception ex)
        {
            conexion.Close();
        }
        finally
        {
            conexion.Close();
        }
        return existe;
    }
}
